﻿var dotnetInstance;
function openContextLeftClick(dotnet) {
    dotnetInstance = dotnet;
    document.getElementById("Grid").addEventListener("mousedown", function (e) {
        if (e.which == 1) {      //based on left click, trigger the right click action
            var ev = new MouseEvent("contextmenu", e);
            e.target.dispatchEvent(ev);
        }
        else if (e.which == 3) {   //based on right click, make a call to c# code to prevent opening of ContextMenu
            dotnetInstance.invokeMethodAsync('RightMouseClick', e.which);
        }
    });
}