using System;
using System.Collections.Generic;

namespace BlazorApp1.Data
{
    public class Order
    {
        public int? OrderId { get; set; }
        public int PersonId { get; set; }
        public string CustomerID { get; set; }
        public DateTime? OrderDate { get; set; }
        public double? Freight { get; set; }
    }
    public class Person
    {
        public int Id { get; set; }
        public List<Order> Orders { get; set; }
    }
    public class WeatherForecast
    {
        public DateTime Date { get; set; }

        public int TemperatureC { get; set; }

        public int TemperatureF => 32 + (int)(TemperatureC / 0.5556);

        public string Summary { get; set; }
    }
}
