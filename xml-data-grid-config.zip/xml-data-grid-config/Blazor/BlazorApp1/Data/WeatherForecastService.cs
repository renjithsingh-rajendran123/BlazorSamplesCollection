using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorApp1.Data
{
    public class WeatherForecastService
    {
        private static List<Person> Personene { get; set; }
        private static readonly string[] Summaries = new[]
        {
            "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
        };
        public List<Person> GetData()
        {
            if (Personene == null)
            {
                Personene = Enumerable.Range(1, 3).Select(x => new Person()
                {
                    Id = x,
                    Orders = new List<Order>(),
                }).ToList();
            }
            return Personene;
        }    
        public List<Order> GetOrders(int val)
        {
            return Personene.Where(x => x.Id == val).FirstOrDefault().Orders.ToList();
        }
        public void InsertRecord(Order val, int PersonId)
        {
            Person value = Personene.Where(s => s.Id == PersonId).FirstOrDefault();
            value.Orders.Insert(0, val);
        }
        public Task<WeatherForecast[]> GetForecastAsync(DateTime startDate)
        {
            var rng = new Random();
            return Task.FromResult(Enumerable.Range(1, 5).Select(index => new WeatherForecast
            {
                Date = startDate.AddDays(index),
                TemperatureC = rng.Next(-20, 55),
                Summary = Summaries[rng.Next(Summaries.Length)]
            }).ToArray());
        }
    }
}
