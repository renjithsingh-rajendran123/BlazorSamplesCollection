﻿//function AppendProgressBar() {
//    var progressbar = document.getElementById("ProgressBar");
//    document.getElementById("ProgressBar").remove();
//    document.getElementById("Grid").getElementsByClassName("e-gridheader")[0].append(progressbar);
//}

window.setGridLoader = (gridId, loaderId) => {
    var grid = document.getElementById(gridId);
    var gridLoader = document.getElementById(loaderId);
    document.getElementById(loaderId).remove();

    grid.getElementsByClassName("e-gridheader")[0].append(gridLoader);
}