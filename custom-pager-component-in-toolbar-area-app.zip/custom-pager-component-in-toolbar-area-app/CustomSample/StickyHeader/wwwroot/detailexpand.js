﻿var dotnetInstance;

function detail(dotnet) {
    dotnetInstance = dotnet; // dotnet instance to invoke C# method from JS 
}

document.addEventListener('click', function (args) {
    if (args.target.classList.contains("e-dtdiagonaldown") || args.target.classList.contains("e-detailrowexpand")) {
        dotnetInstance.invokeMethodAsync('DetailCollapse'); // call C# method from javascript function
    }
})

function RenderPagerTop(id, enabledGrouping, toolbar) {
    var grid = document.getElementById(id);
    var pager = document.getElementsByClassName('e-gridpager');
    var topElement;
    if (enabledGrouping || toolbar) {
        topElement = enabledGrouping ? document.getElementsByClassName('e-groupdroparea') : document.getElementsByClassName('e-toolbar');
    }
    else {
        topElement = document.getElementsByClassName('e-gridheader');
    }
    grid.insertBefore(pager[0], topElement[0]);
}