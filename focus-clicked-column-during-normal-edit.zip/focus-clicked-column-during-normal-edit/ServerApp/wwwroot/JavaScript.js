﻿function focus(ColumnName) {
    var gridform = document.getElementsByClassName("e-gridform")[0];
    if (gridform) {
        //bind onfocus to the default focusing first column. Here CustomerID is the first editable column
        gridform.querySelector("#" + "CustomerID").onfocus = function () {  
            gridform.querySelector("#" + ColumnName).focus(); 
        }
    }
}