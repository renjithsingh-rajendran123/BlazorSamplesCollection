﻿(function (global) {
    global.createComponent = (selector) => {
        // prepare the data
        debugger;
       
        $('#'+selector+'').MdPersianDateTimePicker({
            targetTextSelector: '#' + selector +'',
            selectedDate: new Date('2018/9/30'),
            isGregorian: false,
            dateFormat: 'yyyy-MM-dd',
            calendarViewOnChange: function (date) {
                console.log(date);
            }
        });

    }
})(window);

function GetDateValue(selector) {
    var DateVal = $('#' + selector+'').MdPersianDateTimePicker('getText');
    return DateVal;
}