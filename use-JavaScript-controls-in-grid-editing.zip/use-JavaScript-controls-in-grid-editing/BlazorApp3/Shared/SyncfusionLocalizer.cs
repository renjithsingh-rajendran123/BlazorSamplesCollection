﻿using Syncfusion.Blazor;

namespace BlazorApp3.Shared
{
    public class SyncfusionLocalizer : ISyncfusionStringLocalizer
    {


        // To access the resource file and get the exact value for locale key

        public System.Resources.ResourceManager ResourceManager
        {
            get
            {
              
                // Replace the ApplicationNamespace with your application name.
                 return Resources.SfResources.ResourceManager;
            }
        }

        public string GetText(string key)
        {
            return this.ResourceManager.GetString(key);
        }

       // public ResourceManager ResourceManager { get; }
    }
}
