﻿using BlazorApp1.Data;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorApp1.Pages
{
   public partial class Generic
   {
      
   }
}
