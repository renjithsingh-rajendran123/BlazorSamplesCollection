﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorApp1.Data
{
   public class RestParameter    // data coming from our REST interface
   {
      public string Value { get; set; }
      public string DataType { get; set; }
      public int ID { get; set; }
      public string Name { get; set; }
   }

   public interface IParameter<T> : IParameter
   {
      new T Value { get; set; }
   }

   public interface IParameter
   {
      object Value { get; set; }
      string DataType { get; set; }
      int ID { get; set; }
      string Name { get; set; }
   }

   public class Parameter<T> : IParameter<T>
   {
      public Parameter() { }

      public Parameter(RestParameter dbParameter)
      {
         ID = dbParameter.ID;
         Name = dbParameter.Name;
         stringValue = dbParameter.Value;
         DataType = typeof(T).ToString();
      }

      public int ID { get; set; }
      public string Name { get; set; }
      public int? ParentID { get; set; }
      public string DataType { get; set; }

      public T Value
      {
         get
         {
            TypeConverter converter = TypeDescriptor.GetConverter(typeof(T));
            return (T)converter.ConvertFromString(stringValue);
         }
         set
         {
            TypeConverter converter = TypeDescriptor.GetConverter(typeof(T));
            stringValue = converter.ConvertToString(stringValue);
         }
      }

      object IParameter.Value
      {
         get
         {
            return Value;
         }
         set
         {
            TypeConverter converter = TypeDescriptor.GetConverter(typeof(T));
            Value = (T)converter.ConvertTo(value, typeof(T));
         }
      }


      private string stringValue;
   }
}