﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ClientApp.Data;

namespace ClientApp.Data
{
    public class OrderDataAccessLayer
    {
        IQueryable<T> Orders { get; set; }
        public OrderDataAccessLayer()
        {
            Orders = Enumerable.Range(1, 80000).Select(x => new T()
            {
                OrderID = 1000 + x,
                CustomerID = (new string[] { "ALFKI", "ANANTR", "ANTON", "BLONP", "BOLID" })[new Random().Next(5)],
                EmployeeID = x,
            }).AsQueryable();
        }
        //To Get all Orders details   
        public async Task<IQueryable<T>> GetAllOrders()
        {
            try
            {
                return Orders;
            }
            catch
            {
                throw;
            }
        }

    }
}
