﻿
var dotnetInstance;

function focusoutendedit(dotnet) {
    dotnetInstance = dotnet; // dotnet instance to invoke C# method from JS 
}
document.addEventListener('click', function (args) {
    if (args.target.closest(".e-gridcontent") == null && document.getElementsByClassName("e-gridform")[0] != null || (args.target.querySelector("#OrderID") != null || args.target.id == "OrderID")) {
        dotnetInstance.invokeMethodAsync('EndGridEdit'); // call C# method from javascript function
    }
})
