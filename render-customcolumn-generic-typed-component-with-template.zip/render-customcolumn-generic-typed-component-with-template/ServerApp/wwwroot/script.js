﻿document.addEventListener('keydown', disableTabKey);

function disableTabKey(e) {
    if (e.key == "Tab") {
        e.preventDefault();
    }
}