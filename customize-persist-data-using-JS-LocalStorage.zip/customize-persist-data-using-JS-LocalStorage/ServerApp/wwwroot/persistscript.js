﻿function persistScript() {
    if (window.localStorage["gridGridneTwo"] != undefined) {
        var localstore = JSON.parse(                                   //Fetch the local storage data for Grid using Grid’s ID 
            window.localStorage["gridGridneTwo"]
        );
        localstore.pageSettings = {};                             //Empty the stored filterSettings
        window.localStorage["gridGridneTwo"] = JSON.stringify(localstore);            //Assign the new modified local storage for window.localstorage
    }
}
