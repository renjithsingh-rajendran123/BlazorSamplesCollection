﻿window.convertArray = () => {
    debugger
    //document.getElementById("blazor-license-warning").remove()
    var ele = document.getElementsByClassName("e-grid")[0].ej2_instances[0];
    ele.actionFailure = function (e) { debugger; }
};