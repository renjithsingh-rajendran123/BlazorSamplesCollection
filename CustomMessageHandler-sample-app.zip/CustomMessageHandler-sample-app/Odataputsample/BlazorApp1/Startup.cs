using System;
using System.Security.Cryptography.X509Certificates;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Net.Security;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using BlazorApp1.Data;
using Newtonsoft.Json.Serialization;
using Syncfusion.Blazor;
using System.Net.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.ResponseCompression;
using Microsoft.JSInterop;
using Microsoft.AspNetCore.Http;
using System.Net;

namespace BlazorApp1
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }
        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        // For more information on how to configure your application, visit https://go.microsoft.com/fwlink/?LinkID=398940
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddMvc(option => option.EnableEndpointRouting = false).SetCompatibilityVersion(CompatibilityVersion.Version_3_0);
            services.AddRazorPages();
            services.AddServerSideBlazor();
            services.AddSingleton<WeatherForecastService>();

            services.AddMvc().AddNewtonsoftJson(options =>
            {
                options.SerializerSettings.ContractResolver = new DefaultContractResolver();
            });
            services.AddScoped<HttpClient>(factory => new HttpClient(new HttpClientHandler()
            {
                ServerCertificateCustomValidationCallback = (HttpRequestMessage m, X509Certificate2 f, X509Chain x, SslPolicyErrors d) => true
            }));
            services.AddResponseCompression(opts =>
            {
                opts.MimeTypes = ResponseCompressionDefaults.MimeTypes.Concat(
                    new[] { "application/octet-stream" });
            });
            services.AddCors(options =>
            {
                options.AddPolicy("EnableCORS", builder =>
                {
                    builder.AllowAnyOrigin().AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod().AllowCredentials().Build();
                });
            });
            services.AddSignalR(e =>
            {
                e.MaximumReceiveMessageSize = 10240000;
            });
            services.AddSyncfusionBlazor();
            services.AddScoped<HttpClient>(s =>
            {
                var ijs = s.GetService<IJSRuntime>();
                var context = s.GetRequiredService<IHttpContextAccessor>();
                var navManager = s.GetRequiredService<NavigationManager>();
                Uri hostUri = null;
                try
                {
                    hostUri = new Uri(navManager.BaseUri);
                }
                catch (Exception)
                {
                    var request = context.HttpContext.Request;
                    var pathBase = request.PathBase.Value;
                    var root = request.Scheme + "://" + request.Host;
                    if (!string.IsNullOrEmpty(pathBase) && pathBase != "/")
                    {
                        root += pathBase;
                    }
                    hostUri = new Uri(root);
                }
                var cookieContainer = new CookieContainer();
                HttpClient client = HttpClientFactory.Create(new MessageHandler1(ijs));
                client.BaseAddress = hostUri;

                client.DefaultRequestHeaders.Add("Accept", "application/json");
                client.DefaultRequestHeaders.Add("Accept-Encoding", "br, gzip, deflate");

                if (context != null)
                {
                    try
                    {
                        if (context.HttpContext.Request.Cookies[".AspNetCore.Identity.Application"] != null)
                        {
                            cookieContainer.Add(new Cookie(".AspNetCore.Identity.Application",
                                context.HttpContext.Request.Cookies[".AspNetCore.Identity.Application"], hostUri.AbsolutePath, hostUri.Host));
                        }
                        if (context.HttpContext.Request.Cookies["sso-key"] != null)
                        {
                            cookieContainer.Add(new Cookie("sso-key",
                                context.HttpContext.Request.Cookies["sso-key"], "/", hostUri.Host));
                        }
                    }
                    catch (Exception ex)
                    {
                        // Log
                    }
                }
                return client;
            });

        }

        public class MessageHandler1 : DelegatingHandler
        {
            private int _count = 0;
            private IJSRuntime ijs;

            public MessageHandler1()
            {
            }

            public MessageHandler1(IJSRuntime ijs)
            {
                this.ijs = ijs;
            }

            protected override Task<HttpResponseMessage> SendAsync(
                HttpRequestMessage request, System.Threading.CancellationToken cancellationToken)
            {
                string datareq = "";
                if (request.Content != null)
                    datareq = request.Content.ReadAsStringAsync().Result;      //fetch the data during Update action(PUT request) in Grid
                ijs.InvokeAsync<HttpRequestMessage>("handleError", request, datareq);
                System.Threading.Interlocked.Increment(ref _count);
                request.Headers.Add("X-Custom-Header", _count.ToString());
                return base.SendAsync(request, cancellationToken);
            }
        }
        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();
            app.UseRouting();
            app.UseMvcWithDefaultRoute();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapBlazorHub();
                endpoints.MapFallbackToPage("/_Host");
            });

        }
    }
}
