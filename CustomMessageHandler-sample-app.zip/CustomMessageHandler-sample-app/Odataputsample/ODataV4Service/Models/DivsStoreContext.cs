﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ODataV4Service.Models
{
    public class DivsStoreContext : DbContext
    {
        public DivsStoreContext(DbContextOptions<DivsStoreContext> options)
          : base(options)
        {
        }

        public DbSet<Div> Divs { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            
        }
    }
}
