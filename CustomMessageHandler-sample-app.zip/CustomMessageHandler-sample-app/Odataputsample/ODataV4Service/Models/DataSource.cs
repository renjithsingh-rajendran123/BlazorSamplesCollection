﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ODataV4Service.Models
{
    public static class DataSource
    {
        private static IList<Div> _divs { get; set; }

        public static IList<Div> GetDivs()
        {
            if (_divs != null)
            {
                return _divs;
            }

            _divs = new List<Div>();

            var newGuid = Guid.NewGuid();

            Div related = new Div
            {
                VaCode = 1,
                StStatus = "DivCustomer1",
            };
            _divs.Add(related);
            Div related1 = new Div
            {
                VaCode = 2,
                StStatus = "DivCustomer2",
            };
            _divs.Add(related1);

            related1 = new Div
            {
                VaCode = 3,
                StStatus = "DivCustomer3",
            };
            _divs.Add(related1);

            related1 = new Div
            {
                VaCode = 4,
                StStatus = "DivCustomer4",
            };
            _divs.Add(related1);

            related1 = new Div
            {
                VaCode = 5,
                StStatus = "DivCustomer5",
            };
            _divs.Add(related1);

            related1 = new Div
            {
                VaCode = 6,
                StStatus = "DivCustomer6",
            };
            _divs.Add(related1);

            related1 = new Div
            {
                VaCode = 7,
                StStatus = "DivCustomer7",
            };
            _divs.Add(related1);

            related1 = new Div
            {
                VaCode = 8,
                StStatus = "DivCustomer8",
            };
            _divs.Add(related1);

            related1 = new Div
            {
                VaCode = 9,
                StStatus = "DivCustomer9",
            };
            _divs.Add(related1);


            return _divs;
        }

        private static IList<Group> _groups { get; set; }

        public static IList<Group> GetGroups()
        {
            if (_groups != null)
            {
                return _groups;
            }

            _groups = new List<Group>();

            var newGuid = Guid.NewGuid();

            Group related = new Group
            {
                KdId = 1,
                PrName = "GroupCustomer1",
            };
            _groups.Add(related);
            Group related1 = new Group
            {
                KdId = 2,
                PrName = "GroupCustomer2",
            };
            _groups.Add(related1);

            related1 = new Group
            {
                KdId = 3,
                PrName = "GroupCustomer3",
            };
            _groups.Add(related1);

            related1 = new Group
            {
                KdId = 4,
                PrName = "GroupCustomer4",
            };
            _groups.Add(related1);

            related1 = new Group
            {
                KdId = 5,
                PrName = "GroupCustomer5",
            };
            _groups.Add(related1);

            related1 = new Group
            {
                KdId = 6,
                PrName = "GroupCustomer6",
            };
            _groups.Add(related1);

            related1 = new Group
            {
                KdId = 7,
                PrName = "GroupCustomer7",
            };
            _groups.Add(related1);

            related1 = new Group
            {
                KdId = 8,
                PrName = "GroupCustomer8",
            };
            _groups.Add(related1);

            related1 = new Group
            {
                KdId = 9,
                PrName = "GroupCustomer9",
            };
            _groups.Add(related1);


            return _groups;
        }
        private static IList<Book> _books { get; set; }

        public static IList<Book> GetBooks()
        {
            if (_books != null)
            {
                return _books;
            }

            _books = new List<Book>();

            var newGuid = Guid.NewGuid();

            Book related = new Book
            {
                Id = 1,
                ZeKommentar = "Customer1",
                Pr = GetGroups().Where(x => x.KdId == 1).FirstOrDefault(),
                Va = GetDivs().Where(x => x.VaCode == 1).FirstOrDefault(),
                ZeDiv = 1,
                StoreGroupsId = 1,
                Gender = Gender.Male.ToString(),
                RegistrationDate = DateTime.Now,
                Active = true,
                IsDeleted = false,
                CreditLimit = 1000
            };
            _books.Add(related);

            // book #1
            Book book = new Book
            {
                Id = 2,
                ZeKommentar = "Customer2",
                ZeDiv = 2,
                StoreGroupsId = 2,
                Pr = GetGroups().Where(x => x.KdId == 2).FirstOrDefault(),
                Va = GetDivs().Where(x => x.VaCode == 2).FirstOrDefault(),
                Gender = Gender.Female.ToString(),
                RegistrationDate = DateTime.Now.AddDays(-2),
                Active = false,
                IsDeleted = false,
                CreditLimit = 2000
            };
            _books.Add(book);

            // book #2
            book = new Book
            {
                Id = 3,
                ZeKommentar = "Customer3",
                ZeDiv = 3,
                StoreGroupsId = 3,
                Pr = GetGroups().Where(x => x.KdId == 3).FirstOrDefault(),
                Va = GetDivs().Where(x => x.VaCode == 3).FirstOrDefault(),
                Gender = Gender.Female.ToString(),
                RegistrationDate = DateTime.Now.AddDays(-3),
                Active = true,
                IsDeleted = false,
                CreditLimit = 3000
            };
            _books.Add(book);

            book = new Book
            {
                Id = 4,

                ZeKommentar = "Customer4",
                Gender = Gender.Male.ToString(),
                ZeDiv = 4,
                StoreGroupsId = 4,
                Pr = GetGroups().Where(x => x.KdId == 4).FirstOrDefault(),
                Va = GetDivs().Where(x => x.VaCode == 4).FirstOrDefault(),
                RegistrationDate = DateTime.Now.AddDays(-4),
                Active = true,
                IsDeleted = false,
                CreditLimit = 4000
            };
            _books.Add(book);

            return _books;
        }
    }
}
