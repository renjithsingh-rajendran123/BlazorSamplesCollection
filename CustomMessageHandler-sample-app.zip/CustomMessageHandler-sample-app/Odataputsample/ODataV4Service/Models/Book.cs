﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace ODataV4Service.Models
{

    public class Book
    {
        public Group Pr { get; set; }
        public Div Va { get; set; }
        [Key]
        public int Id { get; set; }
        public string ZeKommentar { get; set; }
        public string Gender { get; set; }
        public decimal? ZeDiv { get; set; }
        public int? StoreGroupsId { get; set; }
        public DateTime RegistrationDate { get; set; }
        public int CreditLimit { get; set; }
        public bool Active { get; set; }
        public bool IsDeleted { get; set; }
    }
    public class Group
    {
        [Key]
        public int KdId { get; set; }
        public string PrName { get; set; }
    }

    public class Div
    {
        [Key]
        public int VaCode { get; set; }
        public string StStatus { get; set; }
    }
    public enum Gender
    {
        [Display(Name = "Male")]
        Male,

        [Display(Name = "Female")]
        Female,

    }
}
