﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNet.OData;
using Microsoft.AspNet.OData.Query;
using Microsoft.AspNet.OData.Routing;
using Microsoft.AspNetCore.Mvc;
using ODataV4Service.Models;

namespace ODataV4Service.Controllers
{
    public class GroupsController : ODataController
    {
        private GroupsStoreContext _db;

        public GroupsController(GroupsStoreContext context)
        {
            _db = context;
            if (context.Groups.Count() == 0)
            {
                foreach (var b in DataSource.GetGroups())
                {
                    context.Groups.Add(b);
                }
                context.SaveChanges();
            }

        }
        // GET api/values
        [HttpGet]
        [ODataRoute]
        public PageResult<Group> Get(ODataQueryOptions opts)
        {
            var results = _db.Groups.AsQueryable();
            var count = results.Count();
            return new PageResult<Group>(results, null, count);
        }

    }
}
