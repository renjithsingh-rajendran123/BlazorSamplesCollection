﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNet.OData;
using Microsoft.AspNet.OData.Query;
using Microsoft.AspNet.OData.Routing;
using Microsoft.AspNetCore.Mvc;
using ODataV4Service.Models;

namespace ODataV4Service.Controllers
{
    public class DivsController : ODataController
    {
        private DivsStoreContext _db;

        public DivsController(DivsStoreContext context)
        {
            _db = context;
            if (context.Divs.Count() == 0)
            {
                foreach (var b in DataSource.GetDivs())
                {
                    context.Divs.Add(b);
                }
                context.SaveChanges();
            }

        }
        // GET api/values
        [HttpGet]
        [ODataRoute]
        public PageResult<Div> Get(ODataQueryOptions opts)
        {
            var results = _db.Divs.AsQueryable();
            var count = results.Count();
            return new PageResult<Div>(results, null, count);
        }
    }
}
