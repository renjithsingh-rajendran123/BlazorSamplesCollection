﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ClientApp.Shared
{

        public class TAction
        {
            public int? ID { get; set; }
            public int? SOHeaderID { get; set; }
            public string Code { get; set; }
            public DateTime? ExecutionDate { get; set; }
            public string RowStatus { get; set; }
        }

    public class SOHeader
    {
        public int? ID { get; set; }

        public int CentroEntregaID { get; set; }
        public string CentroEntregaName { get; set; }
        public string OrderStatus { get; set; }
        public string RowStatus { get; set; }
        public int OrderNumber { get; set; }
        public int ExternalOrderNumber { get; set; }
        public int NetAmount { get; set; }
        public int VatAmount { get; set; }
        public int GrossAmount { get; set; }
        public DateTime? OrderDate { get; set; }
        public DateTime? RequestedShipDate { get; set; }
        public DateTime? SapTransferDate { get; set; }
        public DateTime? ShipDate { get; set; }
    }
    public class ActionType
    {

    }
    public class CentroEntrega
    {
        public int? ID { get; set; }
        public string Name { get; set; }
    }

    public class SOLine
    {
        public int? ID { get; set; }
        public int? LineNumber { get; set; }
        public int? MaterialCode { get; set; }
        public int? MaterialDesc { get; set; }
        public int? OrderCases { get; set; }
        public int? OrderPriceUOM { get; set; }
        public int? PricePerPriceUom { get; set; }
        public int? InvoicePriceUom { get; set; }
        public int? InvoiceCases { get; set; }
        public int? PendingPriceUom { get; set; }
        public int? PendingCases { get; set; }
        public int? ShipPriceUom { get; set; }
        public int? ShipCases { get; set; }
        public int? PriceUom { get; set; }
        public int? RowStatus { get; set; }
        public int? NetAmount { get; set; }
        public int? VATAmount { get; set; }
        public int? GrossAmount { get; set; }
        public int? VAT { get; set; }
    }
    public class OutBoundNote
    {
        public int? ID { get; set; }
        public int? SOLineID { get; set; }
    }
}
