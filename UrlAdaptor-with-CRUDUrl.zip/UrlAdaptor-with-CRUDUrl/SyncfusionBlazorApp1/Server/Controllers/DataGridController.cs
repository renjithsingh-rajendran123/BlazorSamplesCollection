﻿using System.Collections;
using System.Collections.Generic;
using Syncfusion.Blazor;
using Newtonsoft.Json;
using System.Linq;
using System;
using Microsoft.AspNetCore.Mvc;
using SyncfusionBlazorApp1.Shared;


namespace SyncfusionBlazorApp1.Server.Controllers
{


    public class DataGridController : ControllerBase
    {
        public static List<Orders> order = new List<Orders>();
        [HttpPost]
        [Route("api/[controller]")]
        public object Post([FromBody] DataManagerRequest dm)
        {
            if (order.Count == 0)
            {
                BindDataSource();
            }
            IEnumerable DataSource = order.ToList();
            if (dm.Search != null && dm.Search.Count > 0)
            {
                DataSource = DataOperations.PerformSearching(DataSource, dm.Search);  //Search
            }
            if (dm.Sorted != null && dm.Sorted.Count > 0) //Sorting
            {
                DataSource = DataOperations.PerformSorting(DataSource, dm.Sorted);
            }
            if (dm.Where != null && dm.Where.Count > 0) //Filtering
            {
                DataSource = DataOperations.PerformFiltering(DataSource, dm.Where, dm.Where[0].Operator);
            }
            int count = DataSource.Cast<Orders>().Count();
            if (dm.Skip != 0)
            {
                DataSource = DataOperations.PerformSkip(DataSource, dm.Skip);   //Paging
            }
            if (dm.Take != 0)
            {
                DataSource = DataOperations.PerformTake(DataSource, dm.Take);
            }
            return new { result = DataSource, count = count };

        }
        [HttpPost]
        [Route("api/Default/Update")]
        public void Update([FromBody] CRUDModel<Orders> value)
        {
            var re = Request;
            var headers = re.Headers;
            var data = order.Where(or => or.OrderID == value.Value.OrderID).FirstOrDefault();
            if (data != null)
            {
                data.OrderID = value.Value.OrderID;
                data.CustomerID = value.Value.CustomerID;
                data.Freight = value.Value.Freight;
            }
        }
        [HttpPost]
        [Route("api/Default/Insert")]
        public void Insert([FromBody] CRUDModel<Orders> value)
        {
            order.Insert(0, value.Value);
        }
        [HttpPost]
        [Route("api/Default/Delete")]
        public void Delete([FromBody] CRUDModel<Orders> value)
        {
            order.Remove(order.Where(or => or.OrderID == Convert.ToInt32(value.Key)).FirstOrDefault());
        }
        [HttpPost]
        [Route("api/Default/CrudUpdate")]
        public Orders CrudUpdate([FromBody] CRUDModel<Orders> value, string action)
        {
            if (value.Action == "update")
            {
                var ord = value.Value;
                Orders val = order.Where(or => or.OrderID == ord.OrderID).FirstOrDefault();
                val.OrderID = ord.OrderID;
                val.EmployeeID = ord.EmployeeID;
                val.CustomerID = ord.CustomerID;
                val.Freight = ord.Freight;
                val.OrderDate = ord.OrderDate;
                val.ShipCity = ord.ShipCity;
            }
            else if (value.Action == "insert")
            {
                order.Insert(0, value.Value);
            }
            else if (value.Action == "remove")
            {
                order.Remove(order.Where(or => or.OrderID == Convert.ToInt32(value.Key)).FirstOrDefault());
            }
            return value.Value;
        }
        public class CRUDModel<T> where T : class
        {

            [JsonProperty("action")]
            public string Action { get; set; }
            [JsonProperty("table")]
            public string Table { get; set; }
            [JsonProperty("keyColumn")]
            public string KeyColumn { get; set; }
            [JsonProperty("key")]
            public object Key { get; set; }
            [JsonProperty("value")]
            public T Value { get; set; }
            [JsonProperty("added")]
            public List<T> Added { get; set; }
            [JsonProperty("changed")]
            public List<T> Changed { get; set; }
            [JsonProperty("deleted")]
            public List<T> Deleted { get; set; }
            [JsonProperty("params")]
            public IDictionary<string, object> Params { get; set; }
        }
        private void BindDataSource()
        {
            if (order.Count == 0)
            {
                int code = 10;
                for (int i = 1; i < 100; i++)
                {
                    order.Add(new Orders(code + 1, "ALFKI", i + 0, 2.3 * i,true, new DateTime(1991, 05, 15), "Berlin"));
                    order.Add(new Orders(code + 2, "ANATR", i + 2, 3.3 * i,false, new DateTime(1990, 04, 04), "Madrid"));
                    order.Add(new Orders(code + 3, "ANTON", i + 1, 4.3 * i,true, new DateTime(1957, 11, 30), "Cholchester"));
                    order.Add(new Orders(code + 4, "BLONP", i + 3, 5.3 * i,false, new DateTime(1930, 10, 22), "Marseille"));
                    order.Add(new Orders(code + 5, "BOLID", i + 4, 6.3 * i,true, new DateTime(1953, 02, 18), "Tsawassen"));
                    code += 5;
                }
            }
        }
    }

}