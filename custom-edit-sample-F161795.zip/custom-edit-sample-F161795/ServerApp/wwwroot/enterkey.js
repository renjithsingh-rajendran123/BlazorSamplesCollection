﻿var dotnetInstance;

function keyevent(dotnet) {
    dotnetInstance = dotnet; // dotnet instance to invoke C# method from here 
}

function StartEditAction() {
    var gridform = document.getElementsByClassName("e-gridform")[0];
    if (gridform) {
        gridform.onkeydown = function (e) {
            if (e.code == "Enter") {
                dotnetInstance.invokeMethodAsync('EnterKeyPressMethod', true); // call C# method from javascript function
            }
        }
    }
}