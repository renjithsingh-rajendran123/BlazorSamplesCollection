﻿function SearchPosition() {
    var searchtool = document.getElementsByClassName("e-toolbar-right")[0].children[0];   //fetch the search toolbar element
    document.getElementsByClassName("e-toolbar-right")[0].children[0].remove();           //remove the search toolbar element from its original position
    var printtool = document.getElementsByClassName("e-toolbar-left")[0].querySelectorAll(".e-toolbar-item")[3];    //fetch the toolbar item element before which you need to display search tool item
    document.getElementsByClassName("e-toolbar-left")[0].insertBefore(searchtool, printtool);     //insert the search tool item element before the print toolbar item 
}