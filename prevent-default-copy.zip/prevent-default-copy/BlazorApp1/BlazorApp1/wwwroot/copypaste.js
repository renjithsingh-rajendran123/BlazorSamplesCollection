﻿
function copypasteprevent() {
    document.getElementById("GridData").addEventListener("copy", function (evt) {
        // Prevent the default copy action
        evt.preventDefault();
    }, false);
}