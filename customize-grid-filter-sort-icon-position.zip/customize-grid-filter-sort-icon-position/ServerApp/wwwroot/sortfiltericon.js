﻿
function sortfiltericonposition()
{
    var grid = document.getElementsByClassName("e-grid")[0].blazor__instance;
    var gridheaderTable = grid.getHeaderTable();
    for (var i = 0; i < gridheaderTable.querySelectorAll('.e-headercelldiv').length; i++) {
        //find the width of the header cell 
        var boundaries = gridheaderTable.getElementsByClassName("e-headercelldiv")[i].clientWidth;
        //calculate the pixel size the text  
        var textWidth = gridheaderTable.getElementsByClassName("e-headercelldiv")[i].querySelector("span").offsetWidth;
        //changed the postision of sort icon 
        gridheaderTable.getElementsByClassName("e-headercell")[i].querySelector(".e-sortfilterdiv").style.position = "absolute";
        //calculate and define the right CSS for sorticon 
        gridheaderTable.getElementsByClassName("e-headercell")[i].querySelector(".e-sortfilterdiv").style.right = (boundaries - textWidth - 35).toString() + "px";
        //changed the postision of filter icon 
        gridheaderTable.getElementsByClassName("e-headercell")[i].querySelector(".e-filtermenudiv").style.position = "absolute";
        //calculate and define the right CSS for sorticon 
        gridheaderTable.getElementsByClassName("e-headercell")[i].querySelector(".e-filtermenudiv").style.right = (boundaries - textWidth - 25).toString() + "px";
    }
}