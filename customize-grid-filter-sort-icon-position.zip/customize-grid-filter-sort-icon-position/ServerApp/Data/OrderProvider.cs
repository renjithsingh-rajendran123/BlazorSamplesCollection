﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ServerApp.Data
{
    public class OrderProvider
    {
        private List<Order> OrderList = new List<Order>();

        public OrderProvider()
        {
            int initialCode = 10000;
            int Code = initialCode;
            for (int i = 1; i < 100; i++)
            {
                OrderList.Add(new Order(Code - initialCode, Code + 1, "ALFKI", i + 0, 2.3 * i, false, new DateTime(1991, 05, 15), "Berlin", "Denmark", new DateTime(1996, 7, 16), "Kirchgasse 6"));
                OrderList.Add(new Order(Code - initialCode + 1, Code + 2, "ANATR", i + 2, 3.3 * i, true, new DateTime(1990, 04, 04), "Madrid", "Brazil", new DateTime(1996, 9, 11), "Avda. Azteca 123"));
                OrderList.Add(new Order(Code - initialCode + 2, Code + 3, "ANTON", i + 1, 4.3 * i, true, new DateTime(1957, 11, 30), "Cholchester", "Germany", new DateTime(1996, 10, 7), "Carrera 52 con Ave. Bolívar #65-98 Llano Largo"));
                OrderList.Add(new Order(Code - initialCode + 3, Code + 4, "BLONP", i + 3, 5.3 * i, false, new DateTime(1930, 10, 22), "Marseille", "Austria", new DateTime(1996, 12, 30), "Magazinweg 7"));
                OrderList.Add(new Order(Code - initialCode + 4, Code + 5, "BOLID", i + 4, 6.3 * i, true, new DateTime(1953, 02, 18), "Tsawassen", "Switzerland", new DateTime(1997, 12, 3), "1029 - 12th Ave. S."));
                Code += 5;
            }
        }

        public List<Order> GetOrders => OrderList;
    }
}
