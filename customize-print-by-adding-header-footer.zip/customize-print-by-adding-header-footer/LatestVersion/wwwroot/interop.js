window.gridfn = function(){
	sfBlazor.Grid.printGrid = function(e){
		var printWind = window.open('', 'print', 'height=' + window.outerHeight + ',width=' + window.outerWidth + ',tabbar=no');
		printWind.moveTo(0, 0);
		//create the elements 
		var eleHeader = document.createElement("h1");   
		var eleFooter = document.createElement("h2");
		//append content for the elements
		eleHeader.innerHTML = "Print Header Content";
		eleFooter.innerHTML = "Print Footer Content";
		addPrintEleHeader = eleHeader.cloneNode(true);
		addPrintEleFooter = eleFooter.cloneNode(true);
		//append the created elements to the print window
		e.insertBefore(addPrintEleHeader, e.childNodes[0]);
		e.appendChild(addPrintEleFooter);
		printWind.resizeTo(screen.availWidth, screen.availHeight);
		sf.base.print(e, printWind);
	 };
}