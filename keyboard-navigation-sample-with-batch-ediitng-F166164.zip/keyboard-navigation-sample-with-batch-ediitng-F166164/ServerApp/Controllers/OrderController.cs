﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ServerApp.Data;
using System.Diagnostics;

namespace ServerApp.Controllers
{
    [ApiController]
    [Route("order")]    
    public class OrderController : Controller
    {
        public OrderController(OrderProvider orderProvider)
        {
            _orderProvider = orderProvider;
        }

        OrderProvider _orderProvider;

        [HttpGet("{contextId}")]
        public ActionResult<IEnumerable<Order>> GetOrdersAsync(
            int contextId,
            [FromQuery(Name = "$skip")] int? skip,
            [FromQuery(Name = "$top")] int? top)
        {
            Debug.WriteLine($"GetOrders skip: '{skip}' top: '{top}'");
            List<Order> OrderList = _orderProvider.GetOrders;

            var orders = new Orders
            {
                Items = OrderList.Skip(skip ?? 0).Take(top ?? OrderList.Count).ToList(),
                Count = OrderList.Count
            };
            Debug.WriteLine("RecordID | OrderID | CustomerID | EmployeeID");
            foreach (var item in orders.Items)
            {
                Debug.WriteLine($"{item.RecordID:00'000'000} | {item.OrderID:0000000} | {item.CustomerID} | {item.EmployeeID:000000}");
            }
            return Ok(orders);
        }
    }
}
