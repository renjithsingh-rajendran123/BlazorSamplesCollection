﻿//function scroll(index, totalItemCount, gridHeight)
function scroll(index)
{
    var grid = document.getElementsByClassName("e-grid")[0].blazor__instance;
    var rowHeight = grid.getRowHeight();
    var exactScrollTop = (index - 1) * rowHeight;
    //if (exactScrollTop > ((totalItemCount * rowHeight) - gridHeight)) {
    //    exactScrollTop = (totalItemCount * rowHeight) - gridHeight;
    //}
    grid.getContent().scrollTop = exactScrollTop;
    //do the calculations to set the scrollTop value for grid content
}
