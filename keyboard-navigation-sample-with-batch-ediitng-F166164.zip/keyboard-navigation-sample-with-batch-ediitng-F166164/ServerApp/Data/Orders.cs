﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ServerApp.Data
{
    public class Orders
    {
        public List<Order> Items { get; set; } = new List<Order>();

        public int Count { get; set; }
    }
}
